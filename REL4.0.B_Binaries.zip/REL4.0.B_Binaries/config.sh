cp sample.sh /usr/bin
sync
chmod +x /usr/bin/sample.sh
sync
cp ble.sh /usr/bin
sync
chmod +x /usr/bin/ble.sh
sync
cp iWave_APP.service /lib/systemd/system/
sync
systemctl daemon-reload
sync
mkdir /home/root/Application/
sync
mkdir /home/root/Application/Logs/
sync
cp iWave_APP_Log.txt /home/root/Application/Logs/iWave_APP_Log.txt
sync
mkdir /home/root/Device/
sync
mkdir /home/root/Device/Logs/
sync
cp iWave_Device_Log.txt /home/root/Device/Logs/
sync
cp iWave_Device_Power_Status_Log.txt /home/root/Device/Logs/
sync
cp cpin /etc/
sync
tar -xvjf REL4.0.B.tar.bz2 
sync
cp REL4.0.B/lib* /usr/lib/
sync
cp REL4.0.B/J1939_APP /iwtest/Application/
sync
chmod +x /iwtest/Application/J1939_APP
sync


