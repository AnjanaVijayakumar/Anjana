#!/bin/bash
file=/home/root/Application/Logs/iWave_APP_Log.txt
minimumsize=10000000
actualsize=$(wc -c <"$file")
if [ $actualsize -ge $minimumsize ]; then
    echo size is over $minimumsize bytes
    #truncate -s 0 $file
        cp /dev/null $file
fi
file1=/home/root/Device/Logs/iWave_Device_Log.txt
minimumsize=10000000
actualsize=$(wc -c <"$file1")
if [ $actualsize -ge $minimumsize ]; then
    echo size is over $minimumsize bytes
    #truncate -s 0 $file1
        cp /dev/null $file1
fi
OUTPUT=$(systemctl show iWave_APP.service -p NRestarts)
printf "$OUTPUT\n" >> /home/root/Application/Logs/iWave_APP_Log.txt
OUTPUT1=$(date)
printf "$OUTPUT1\n" >> /home/root/Application/Logs/iWave_APP_Log.txt

